function calculateTax() {
    function incomeval(income) {
        // Validate that income is a valid number or decimal
        const regex = /^[0-9]+(\.[0-9]{1,2})?$/;
        return regex.test(income);
    }

    let input = document.getElementById('income').value;

    // Validate user input until it's correct
    while (!incomeval(input)) {
        alert("Invalid input. Please enter a valid number (e.g., 19000 or 19000.00).");
        input = document.getElementById('income').value;
    }

    input = parseFloat(input); // Convert input to a number
    const result = document.getElementById('taxOutput');
    result.innerHTML = ""; // Clear previous results
    let taxtotal = 0; // Initialize total tax variable
    let highestTax = 0; // Track the highest tax amount
    let highestTaxLine = ""; // Track which range has the highest tax

    // Tax Bracket Calculations
    const taxBrackets = [
        { range: [0, 11000], rate: 0.10 },
        { range: [11001, 44725], rate: 0.12 },
        { range: [44726, 95375], rate: 0.22 },
        { range: [95376, 182100], rate: 0.24 },
        { range: [182101, 231250], rate: 0.32 },
        { range: [231251, 578125], rate: 0.35 },
        { range: [578126, Infinity], rate: 0.37 }
    ];

    // Loop through each tax bracket and calculate tax
    for (let bracket of taxBrackets) {
        let lowerLimit = bracket.range[0];
        let upperLimit = bracket.range[1];
        let taxableIncome = Math.min(input, upperLimit) - lowerLimit;

        if (taxableIncome > 0) {
            let taxAmount = Math.round(taxableIncome * bracket.rate); // Calculate tax and round to nearest dollar
            taxtotal += taxAmount;

            // Create a line for the current range
            let rangeText = `Income from $${lowerLimit} to $${upperLimit} taxed at ${(bracket.rate * 100).toFixed(0)}%: $${taxAmount}`;
            let taxLine = document.createElement("div");
            taxLine.textContent = rangeText;

            // Check for highest tax amount
            if (taxAmount > highestTax) {
                highestTax = taxAmount;
                highestTaxLine = taxLine; // Store the current line to highlight later
            }

            // Append the line to the results
            result.appendChild(taxLine);
        }
    }

    // Highlight the highest tax line in red
    if (highestTaxLine) {
        highestTaxLine.style.color = "red";
    }

    // Display total tax owed as bold
    let totalLine = document.createElement("div");
    totalLine.innerHTML = `<strong>Total Tax Owed: $${taxtotal}</strong>`;
    result.appendChild(totalLine);
}
